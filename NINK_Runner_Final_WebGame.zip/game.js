
window.onload = function () {
  const gameArea = document.getElementById("game-area");
  gameArea.innerHTML = "<h2>🕹️ Welcome to NINK Runner!</h2><p>Game is now auto-playing...</p>";
};
