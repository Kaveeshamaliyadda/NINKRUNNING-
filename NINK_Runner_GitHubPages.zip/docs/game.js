
function startGame() {
    const canvas = document.getElementById("gameCanvas");
    const ctx = canvas.getContext("2d");
    let score = 0;

    function draw() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = "#0f0";
        ctx.fillRect(50, canvas.height - 60, 30, 30); // Ninja
        ctx.fillText("Running...", 100, 100);
        document.getElementById("score").textContent = "Score: " + score;
        score++;
    }

    setInterval(draw, 100);
}
